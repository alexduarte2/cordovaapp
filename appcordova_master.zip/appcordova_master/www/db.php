<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12789214_akademik","12345","id12789214_akademik") or die ("could not connect database");
?>