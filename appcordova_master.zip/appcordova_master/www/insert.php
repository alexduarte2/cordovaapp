<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $judul=$_POST['judul'];
 $durasi=$_POST['durasi'];
 $harga=$_POST['harga'];
 $q=mysqli_query($con,"INSERT INTO `rincian_kursus` (`judul`,`durasi`,`harga`) VALUES ('$judul','$durasi','$harga')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>